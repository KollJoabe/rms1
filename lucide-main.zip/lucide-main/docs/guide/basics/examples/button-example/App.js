import Button from "./Button";

export default function App() {
  return <Button />;
}
