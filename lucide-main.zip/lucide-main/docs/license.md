---
aside: false
editLink: false
---

# Lucide License

<!--@include: ../LICENSE -->
