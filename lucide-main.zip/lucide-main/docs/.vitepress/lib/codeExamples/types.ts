export type CodeExampleType = {
  title: string;
  language: string;
  code: string;
}[];
