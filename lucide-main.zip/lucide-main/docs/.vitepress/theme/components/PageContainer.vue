<template>
  <div class="container">
    <slot />
  </div>
</template>

<style scoped>
.container {
  padding: 32px;
  padding-top: 33px;
}
</style>
