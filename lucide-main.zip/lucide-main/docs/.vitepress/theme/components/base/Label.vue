
<template>
  <h2 class="label"><slot/></h2>
</template>

<style scoped>
.label {
  letter-spacing: 0.4px;
  line-height: 28px;
  font-size: 14px;
  font-weight: 600;
  border: 0;
  padding: 0;
  margin: 0;
}
</style>
